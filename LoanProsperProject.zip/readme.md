<font size = 5><b>Loan Characteristics and Borrower APR</b></font><br><br>
<font size = 4><b>By Brett Gardner</b></font>

<font size = 5><b>Dataset</b></font><br><br>
The dataset can be accessed here: https://www.google.com/url?q=https://s3.amazonaws.com/udacity-hosted-downloads/ud651/prosperLoanData.csv&sa=D&ust=1554486256021000. The dictionary can be viewed here: https://www.google.com/url?q=https://docs.google.com/spreadsheet/ccc?key%3D0AllIqIyvWZdadDd5NTlqZ1pBMHlsUjdrOTZHaVBuSlE%26usp%3Dsharing&sa=D&ust=1554486256024000. The dataset consisted of 113,937 loans. 

<font size = 5><b>Summary and Key Insights</b></font><br><br>
I found that Borrower APR was negatively correlated with average credit score and ProsperScore. The negative correlation was strongest with ProsperScore. The lower the rating, the higher the APR; the higher the rating, the lower APR. 

I was surprised credit score didn't have a higher negative correlation with Borrower APR. This shows that much more goes into deriving a ProsperScore than the credit rating. 
